#include "stdio.h"
#include "string.h"
 
int main()
{
    char* msg = "Hello World";
    printf("%s", msg);
	return 0;
}
